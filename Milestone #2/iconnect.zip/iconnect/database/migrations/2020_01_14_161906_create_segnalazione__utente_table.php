<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSegnalazioneUtenteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('segnalazione_utente', function (Blueprint $table) {
            $table->bigInteger('Utente')->unsigned();
            $table->bigInteger('Segn')->unsigned();

            $table->foreign('Utente')
            ->references('idUtente')
            ->on('utente');

            $table->foreign('Segn')
                  ->references('idS')
                  ->on('segnalazione');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('segnalazione__utente');
    }
}
