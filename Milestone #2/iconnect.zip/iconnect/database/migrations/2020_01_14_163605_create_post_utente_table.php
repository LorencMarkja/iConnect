<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostUtenteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('post_utente', function (Blueprint $table) {

            $table->bigInteger('Post')->unsigned();
            $table->bigInteger('Utente')->unsigned();

            $table->foreign('Post')
                  ->references('idP')
                  ->on('post');
            
            $table->foreign('Utente')
                  ->references('idUtente')
                  ->on('utente');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('post_utente');
    }
}
