<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePersonaleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('personale', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('Utente')->unsigned();
            $table->string('Dipartimento');
            $table->timestamps();

            $table->foreign('Utente')
                  ->references('idUtente')
                  ->on('utente');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('personale');
    }
}
