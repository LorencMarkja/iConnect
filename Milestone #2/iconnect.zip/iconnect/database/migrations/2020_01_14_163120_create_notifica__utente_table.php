<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificaUtenteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifica_utente', function (Blueprint $table) {
            $table->bigInteger('Utente')->unsigned();
            $table->bigInteger('Notifica')->unsigned();

            $table->foreign('Utente')
            ->references('idUtente')
            ->on('utente');

            $table->foreign('Notifica')
                  ->references('idNotifica')
                  ->on('notifica');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifica__utente');
    }
}
