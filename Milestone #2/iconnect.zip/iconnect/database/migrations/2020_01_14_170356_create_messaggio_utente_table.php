<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMessaggioUtenteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('messaggio_utente', function (Blueprint $table) {
            
            $table->bigInteger('text')->unsigned();
            $table->bigInteger('Utente')->unsigned();
            
            $table->enum('tipologia',['invio','ricezione']);

            $table->timestamps();
            
            $table->foreign('text')
                  ->references('idM')
                  ->on('messaggio');
            
            $table->foreign('Utente')
                  ->references('idUtente')
                  ->on('utente');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('messaggio_utente');
    }
}
