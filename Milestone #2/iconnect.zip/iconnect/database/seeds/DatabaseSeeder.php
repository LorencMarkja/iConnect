<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         //$this->call(UsersTableSeeder::class);
         $this->call(UtenteSeed::class);
         $this->call(ComSeed::class);
         $this->call(GroupSeed::class);
    }
}
