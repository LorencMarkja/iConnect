<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notifica extends Model
{
    protected $table = 'notifica';
    
    public function utente()
    {
        return $this->belongsToMany('App\utente','notifica_utente');
    }
}
