<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class amministratore extends Model
{
    protected $table = 'amministratore';

    public function segnalazione()
    {
        return $this->hasMany('App\segnalazione');
    }

}
