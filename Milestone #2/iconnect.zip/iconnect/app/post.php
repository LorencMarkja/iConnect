<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class post extends Model
{
    protected $table = 'post';
    protected $primaryKey='idP';
    public $timestamps = false;
    
    public function gruppo()
    {
        return $this->belongsToMany('App\gruppo','gruppo_post');
    }

    public function utente()
    {
        return $this->belongsToMany('App\utente','post_utente');
    }


}
