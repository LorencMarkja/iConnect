<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class segnalazione extends Model
{
    protected $table = 'segnalazione';
    protected $primaryKey='ids';
    public $timestamps=false;

    public function amministratore()
    {
        return $this->belongsTo('App\amministratore');
    }
    
    public function utente()
    {
        return $this->belongsToMany('App\utente','segnalazione_utente');
    }
    
}
