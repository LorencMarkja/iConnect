<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class utente extends Model
{
    protected $table = 'utente';
    protected $primaryKey='idUtente'; //
    //

    public function segnalazione()
    {
        return $this->belongsToMany('App\segnalazione','segnalazione_utente');
    }

    public function notifica()
    {
        return $this->belongsToMany('App\notifica','notifica_utente');
    }

    public function gruppo()
    {
        return $this->belongsToMany('App\gruppo','gruppo_utente');
    }

    public function post()
    {
        return $this->belongsToMany('App\post','post_utente');
    }

    public function messaggio()
    {
        return $this->belongsToMany('App\messaggio','messaggio_utente');
    }

    public function docente()
    {
        return $this->hasOne('App\docente','idUtente','Utente');
    }

    public function studente()
    {
        return $this->hasOne('App\studente','idUtente','Utente');
    }

    public function personale()
    {
        return $this->hasOne('App\personale','Utente','idUtente');
        
    }
}
