<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class personale extends Model
{
    protected $table = 'personale';

    public $timestamps = false;
    
    public function creagruppo()
    {
        return $this->morphToMany('App\gruppo', 'docente_gruppo_personale');
    }

    public function utente()
    {
        return $this->belongsTo('App\utente');
    }
}
