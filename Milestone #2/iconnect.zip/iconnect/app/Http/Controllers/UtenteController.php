<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\utente;   

class UtenteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $utente= utente::all();
        return $utente;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $utente= new utente();
        $utente-> nome = $request->nome;
        $utente-> cognome = $request->cognome;
        $utente-> email = $request->email;
        $utente-> password = $request->password;
        $utente-> telefono = $request->telefono;
        $utente-> ruolo = $request->ruolo;

        $utente->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $idUtente
     * @return \Illuminate\Http\Response
     */
    public function show($idUtente)
    {
       
        $utente = utente:: find($idUtente);
        return $utente;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $idUtente)
    {
        $utente = utente:: find ($idUtente);
        $utente-> telefono = $request->telefono;
        $utente-> save();

        }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $utente = utente ::find($id);
        $utente-> delete();
    }
}
