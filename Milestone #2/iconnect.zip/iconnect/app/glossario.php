<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class glossario extends Model
{
    protected $table = 'glossario';
    //
}
