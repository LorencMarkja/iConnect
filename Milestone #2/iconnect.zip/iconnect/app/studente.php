<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class studente extends Model
{
    protected $table = 'studente';

    public $timestamps = false;
    
    public function utente()
    {
        return $this->belongsTo('App\utente');
    }
}
