<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class docente extends Model
{
    protected $table = 'docente';

    public $timestamps = false;
    
    public function creagruppo()
    {
        return $this->morphToMany('App\gruppo', 'docente_gruppo_personale');
    }

    public function utente()
    {
        return $this->belongsTo('App\utente');
    }

}
