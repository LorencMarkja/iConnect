<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class messaggio extends Model
{
    protected $table = 'messaggio';
    protected $primaryKey='idM';
    public $timestamps=false;
    public function utente()
    {
        return $this->belongsToMany('App\utente','messaggio_utente');
    }

    public function glossario()
    {
        return $this->hasOne('App\glossario');
    }

    public function gruppo()
    {
        return $this->belongsTo('App\gruppo');
    }
}
