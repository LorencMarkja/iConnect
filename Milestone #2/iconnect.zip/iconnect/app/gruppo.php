<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gruppo extends Model
{
    protected $table = 'gruppo';
    protected $primaryKey='CodU';
    public $timestamps = false;
    
    public function utente()
    {
        return $this->belongsToMany('App\utente','gruppo_utente');
    }

    public function post()
    {
        return $this->belongsToMany('App\post','gruppo_post');
    }

    public function docente()
    {
        return $this->morphedByMany('App\docente', 'docente_gruppo_personale');
    }

    public function personale()
    {
        return $this->morphedByMany('App\personale', 'docente_gruppo_personale');
    }

    public function messaggio()
    {
        return $this->hasMany('App\messaggio');
    }
  
}
